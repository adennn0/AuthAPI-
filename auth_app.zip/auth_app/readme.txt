Uygulamayı kullanmak için öncelikle masaüstü dışında bir klasöre taşıyın ardından terminale 

1- flutter clean

2- flutter pub get

3- flutter create .

komutlarını teker teker yazıp uyguladıktan sonra uygulamayı deneyimleyebilirsiniz
