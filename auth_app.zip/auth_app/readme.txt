Uygulamayı kullanmak için öncelikle masaüstü dışında bir klasöre taşıyın flutter ve dart uzantılarını indirdikten sonra terminale 

1- flutter clean

2- flutter pub get

3- flutter create .

komutlarını teker teker yazıp uyguladıktan sonra lib klasöründeki main.dart dosyasını run edip uygulamayı deneyimleyebilirsiniz
