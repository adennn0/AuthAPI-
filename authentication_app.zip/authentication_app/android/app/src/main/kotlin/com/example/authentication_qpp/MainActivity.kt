package com.example.authentication_qpp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
